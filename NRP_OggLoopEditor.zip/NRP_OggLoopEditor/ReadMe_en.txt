-----------------------------------------------
[Title  ] NRP_OggLoopEditor
[Version] 1.00
-----------------------------------------------

-----------------------------------------------
■Author
-----------------------------------------------
Author　　 ：Takeshi Sunagawa
URL　　　　：http://newrpg.seesaa.net/
Mail  　　 ：newrpg2012@gmail.com
X (Twitter)：https://x.com/NewRPGProject

-----------------------------------------------
■History
-----------------------------------------------
◆2026/06/22 ver1.00
- Release!

-----------------------------------------------
■Terms
-----------------------------------------------
There are no restrictions.
Modification, redistribution freedom, commercial availability,
and rights indication are also optional.
The author is not responsible,
but will deal with defects to the extent possible.

However, when redistributing, please comply with
the licenses of the libraries you use.
That said, as long as you don't delete
the license-related .txt files, there shouldn't be any problems.
-----------------------------------------------

